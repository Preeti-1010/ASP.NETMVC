 @"insert into registration1(userid , name,gender, age, address,contactno, password, confirmpassword )
        values('" + txtuserId1.Text + "','"+ txtName.Text +"', '" + gender+"',"+ Convert.ToInt64(txtage.Text) + 
                  ",'"+ txtaddress.Text+"',"  + Convert.ToInt64(txtcontactno.Text) + ",'"+txtpassword.Text+"','" + txtconfirmpassword.Text + "')";