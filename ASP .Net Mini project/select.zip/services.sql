insert into bookticket(name, gender,age,departurefrom, arrivalto, dateofjourney, vechiles,mobileno)
values('adtiya','male',18,'delhi','pune','10/02/1994','acbus',123456);