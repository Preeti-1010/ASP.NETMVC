insert into customers(customer_name,customer_contact)
values('ITM',656768)