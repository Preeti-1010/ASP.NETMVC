insert into feedback (userid , name,gender, age,description)
values('pooja@gmail.com','pooja','female',32,'nice performance')