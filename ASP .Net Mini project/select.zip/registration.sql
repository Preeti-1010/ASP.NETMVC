insert into registration1(userid , name,gender, age, address,contactno, password, confirmpassword )
values('bpbestpreeti@gmail.com','Preeti Pandey','Female',21,'betiahata',5757578,'test','test');